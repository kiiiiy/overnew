# account/migrations/000X_populate_data.py 파일의 내용 (X는 이전 파일보다 큰 번호)

from django.db import migrations

# =================================================================
# 1. NewsCategory 초기 데이터 생성 함수
# =================================================================
def create_initial_news_categories(apps, schema_editor):
    NewsCategory = apps.get_model('account', 'NewsCategory')
    
    categories = [
        {'code': 'politics', 'name': '정치'},
        {'code': 'economy', 'name': '경제'},
        {'code': 'society', 'name': '사회'},
        {'code': 'culture', 'name': '생활/문화'},
        {'code': 'it', 'name': 'IT/과학'},
        {'code': 'world', 'name': '세계'},
        {'code': 'entertainment', 'name': '연예'},
        {'code': 'sports', 'name': '스포츠'},
    ]

    for data in categories:
        # 데이터가 이미 존재하는지 확인 후 생성합니다. (중복 방지)
        # NewsCategory.objects.create(code=data['code'], name=data['name'])
        if not NewsCategory.objects.filter(code=data['code']).exists():
            NewsCategory.objects.create(**data)

# =================================================================
# 2. Media 초기 데이터 생성 함수
# =================================================================
def create_initial_media_outlets(apps, schema_editor):
    Media = apps.get_model('account', 'Media')

    media_list = [
        # 종합
        {'code': 'kh', 'name': '경향신문'}, {'code': 'hani', 'name': '한겨레'},
        {'code': 'ohmynews', 'name': '오마이뉴스'}, {'code': 'pressian', 'name': '프레시안'},
        {'code': 'donga', 'name': '동아일보'}, {'code': 'chosun', 'name': '조선일보'},
        {'code': 'joongang', 'name': '중앙일보'}, {'code': 'munhwa', 'name': '문화일보'},
        # 방송/통신
        {'code': 'yonhap', 'name': '연합뉴스'}, {'code': 'ytn', 'name': 'YTN'},
        {'code': 'mbc', 'name': 'MBC'}, {'code': 'kbs', 'name': 'KBS'},
        {'code': 'sbs', 'name': 'SBS'}, {'code': 'channela', 'name': '채널A'},
        {'code': 'hankyungtv', 'name': '한국경제TV'}, # 중복 방지를 위해 수정된 코드
        {'code': 'jtbc', 'name': 'JTBC'}, {'code': 'tbs', 'name': 'TBS'},
        # 경제
        {'code': 'hankyung', 'name': '한국경제'}, {'code': 'maeil', 'name': '매일경제'},
        {'code': 'sedaily', 'name': '서울경제'}, {'code': 'etoday', 'name': '이투데이'},
        # 지역
        {'code': 'kookje', 'name': '국제신문'}, {'code': 'busan', 'name': '부산일보'},
        {'code': 'jeonjumbc', 'name': '전주MBC'}, {'code': 'cjb', 'name': 'CJB청주방송'},
        {'code': 'jibs', 'name': 'JIBS'}, {'code': 'kbc', 'name': 'kbc광주방송'},
        # 포토
        {'code': 'xinhua', 'name': '신화사 연합뉴스'}, {'code': 'ap', 'name': 'AP연합뉴스'},
        {'code': 'epa', 'name': 'EPA연합뉴스'},
    ]

    for data in media_list:
        if not Media.objects.filter(code=data['code']).exists():
            Media.objects.create(**data)


class Migration(migrations.Migration):
    dependencies = [
        # ⚠️ 중요: 여기에 이전 마이그레이션 파일의 이름 (뒤의 .py 제외)을 넣어주세요.
        # 예시: ('account', '0004_usermedia_usermedia')
        ('account', '0001_initial'), 
    ]

    operations = [
        # RunPython을 사용하여 위에서 정의한 데이터 생성 함수를 실행합니다.
        migrations.RunPython(create_initial_news_categories, migrations.RunPython.noop),
        migrations.RunPython(create_initial_media_outlets, migrations.RunPython.noop),
    ]